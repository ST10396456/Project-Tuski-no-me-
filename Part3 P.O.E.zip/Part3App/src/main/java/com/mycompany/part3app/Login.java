/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.part3app;

import java.util.Scanner;

/**
 *
 * @author Wandile
 */
class Login {
     public static boolean checkUsername(String RegUsername){
        return (RegUsername.length() <= 5 && RegUsername.matches("(.*)_(.*)"));
    }
    
    public static boolean checkPasswordComplexity(String RegPassword){
        int countSpecial = 0, countNumber = 0, countCapital = 0, countLength = 0;
        String specialCharacter = "!@#$%&*()'+,-./:;<=>?[]^_`{|}";
        
        if (RegPassword.length() >= 8){
            countLength++;
        }
        
        for (int i = 0; i < RegPassword.length(); i++){
            if (specialCharacter.contains(Character.toString(RegPassword.charAt(i)))){
                countSpecial++;
            }
        }

        for (int j = 0; j < RegPassword.length(); j++){
            if (Character.isDigit(RegPassword.charAt(j))){
                countNumber++;
            }
        }
        
        for (int k = 0; k < RegPassword.length(); k++){
            if (Character.isUpperCase(RegPassword.charAt(k))){
                countCapital++;
            }
        }
        
        return (countSpecial >= 1 && countLength >= 1 && countNumber >= 1 && countCapital >= 1);
    }
    
    public static String registerUser(String[] details){
        String RegUsername, RegPassword;        
        boolean userCont = false, passCont = false;
        Scanner input = new Scanner(System.in);
        
        while (userCont == false){
            System.out.println("Please enter your username");
            RegUsername = input.nextLine();
            if (checkUsername(RegUsername)){
                details[0] = RegUsername;
                System.out.println("Username was successfully captured!");
                userCont = true;
            }else{
                System.out.println("Username is not the correct format, please ensure that your username contains an underscore and is no more than 5 characters in length.");
            }
        }
        
        while (passCont == false){
            System.out.println("Please enter your password (8 characters or more, must contain a number, special character and capital letter)");
            RegPassword = input.nextLine();
            if (checkPasswordComplexity(RegPassword)){
                details[1] = RegPassword;
                System.out.println("Password was successfully captured.");
                passCont = true;
            }else{
                System.out.println("Password is not the correct format, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.");
            }
        }        
        
        System.out.println("Enter your first name");
        details[2] = input.nextLine();
        
        System.out.println("Enter your last name");
        details[3] = input.nextLine();
        
        return "Successfully registered";
    }
    
    public static boolean loginUser(String[] details, String LogUsername, String LogPassword){
                
        return (details[0].equals(LogUsername) && details[1].equals(LogPassword));
    }
    
    public static String returnLoginStatus(String[] details, String LogUsername, String LogPassword){
        
        
        if (loginUser(details, LogUsername, LogPassword) == true){
            return ("Welcome Back User! " + details[2] + " " + details[3] + "Enjoy your use of the System!");
        }else{
            return("Username or password incorrect, please try again.");
        }
    
}
}    
