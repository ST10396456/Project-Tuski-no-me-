/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.part3app;

/**
 *
 * @author Wandile
 */
class Task {
      public static boolean checkTaskDescription(String taskDescription){
        boolean validDescriptionLength = taskDescription.length() <= 50;
        if (validDescriptionLength){
            System.out.println("Task successfully captured");
        }else{
            System.out.println("Please enter a task description of less than 50 characters");
        }
        return validDescriptionLength;
    }
    
    public static String createTaskID(String taskName, String taskDeveloperDetails, int taskNumber){
        String taskID = (taskName.substring(0, 2) + ":" + taskNumber + ":" + taskDeveloperDetails.substring(taskDeveloperDetails.indexOf(" ") - 3, taskDeveloperDetails.indexOf(" "))).toUpperCase();
        return taskID;
    }
    
    public static String printTaskDetails(String taskStatus, String taskDeveloperDetails, String taskName, String taskDescription, String taskID, int taskNumber, int taskDuration){
        return (taskStatus + " " + taskDeveloperDetails + " " + taskNumber + " " + taskName + " " + taskDescription + " " + taskID + " " + taskDuration);
    }
    
    public static int returnTotalHours(int totalHours, int taskDuration){
        totalHours = totalHours + taskDuration;
        return totalHours;
    }
    
}
