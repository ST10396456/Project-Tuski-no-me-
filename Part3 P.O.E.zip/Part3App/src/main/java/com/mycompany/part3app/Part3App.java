/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.part3app;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import javax.swing.JDialog;
import javax.swing.JOptionPane;

/**
 *
 * @author Wandile
 */
public class Part3App {

    public static void main(String[] args) {
      
        String[] details = new String[4];
        boolean loggedIn = false;
        String loginStatus;
        
        System.out.println(Login.registerUser(details));        

        while (loggedIn == false){
            Scanner input = new Scanner(System.in);
            System.out.println(" Please Your Enter username");
            String loginUsername = input.nextLine();
        
            System.out.println("Please Your Enter password");
            String loginPassword = input.nextLine();
            
            loginStatus = Login.returnLoginStatus(details, loginUsername, loginPassword);
            if (!loginStatus.equals("This Username or password is incorrect, please try again.")){
                loggedIn = true;
                System.out.println(loginStatus);
            }else{
                System.out.println(loginStatus);
            }
        }
        
        int menuOption = 0, 
                
        AmountOfTasks= 0,
                
        TotalHours = 0;
        Scanner x = new Scanner(System.in);
        boolean found = false;
        
        int[] taskNumber = null;
        int[] taskDuration = null;
        String[] taskName = null;
        String[] taskDescription = null;
        String[] taskDeveloperDetails = null;
        String[] taskID = null;
        String[] taskStatus = null;
        
        System.out.println("Welcome to EasyKanban");
        
        while (menuOption != 3) {
            
            System.out.println("Select an option below by inputting a number:");
            System.out.println("1. Add tasks");
            System.out.println("2. Show report");
            System.out.println("3. Exit");
            
            menuOption = x.nextInt();
            
            switch (menuOption){
                case 1:
                    System.out.println("Enter number of tasks to be simulated:");
                    AmountOfTasks = x.nextInt();
                    x.nextLine();
                    taskNumber = new int[AmountOfTasks];
                    taskDuration = new int[AmountOfTasks];
                    taskName = new String[AmountOfTasks];
                    taskDescription = new String[AmountOfTasks];
                    taskDeveloperDetails = new String[AmountOfTasks];
                    taskID = new String[AmountOfTasks];
                    taskStatus = new String[AmountOfTasks];
                    for (int i = 0; i < AmountOfTasks; i++){
                        taskNumber[i] = i;
                        System.out.println("Enter name of task  " + taskNumber[i] + ":");
                        taskName[i] = x.nextLine();
                        boolean contTaskDesc = false;
                        
                        while (contTaskDesc == false){
                            System.out.println("Enter description of task  " + taskNumber[i] + ":");
                            taskDescription[i] = x.nextLine();
                            if (Task.checkTaskDescription(taskDescription[i])){
                                contTaskDesc = true;
                            }
                        }
                
                        System.out.println("Enter full name of the developer assigned to task " + taskNumber[i] + ":");
                        taskDeveloperDetails[i] = x.nextLine();
                
                        System.out.println("Enter the estimated duration of task " + taskNumber[i] + ":");
                        taskDuration[i] = x.nextInt();
                
                        x.nextLine();
                
                        System.out.println("Enter the status of task " + taskNumber[i] + " ('To Do', 'Done, or 'Doing'):");
                        taskStatus[i] = x.nextLine();
                        System.out.println();
                
                        taskID[i] = Task.createTaskID(taskName[i], taskDeveloperDetails[i], taskNumber[i]);
                        
                        JDialog component = new JDialog();
                        component.setAlwaysOnTop(true);
                
                        JOptionPane.showMessageDialog(component, Task.printTaskDetails(taskStatus[i], taskDeveloperDetails[i], taskName[i], taskDescription[i], taskID[i], taskNumber[i], taskDuration[i]));
                        
                        TotalHours = Task.returnTotalHours(TotalHours, taskDuration[i]);
                        
                        component.dispose();
                        }
                    System.out.println("Combined estimated number of hours: " + TotalHours);
                     //totalHours is displayed
                    System.out.println("Total duration of all tasks combined: " + TotalHours + " hours\n");
                    
                    //displays all task names, developers and task duration of a task with status "Done" case sensitive
                    System.out.println("All tasks with the status: 'Done'");
                    for (int i = 0; i < AmountOfTasks;i++){
                        if (taskStatus[i].equals("Done")){
                            System.out.println(taskDeveloperDetails[i] + ", " + taskName[i] + ", " + taskDuration[i]);
                        }
                    }
                    
                    //displays the longest task and the developer of the task
                    System.out.println("\nTask with the longest Duration:");
                    System.out.println(longestTask(AmountOfTasks, taskDuration, taskDeveloperDetails));
                    
                    //displays result of task that user searches for by task name   
                    System.out.println("\nEnter a Task Name to search and display information: ");
                    String search = x.nextLine();
                    System.out.println(searchTaskName(  AmountOfTasks, taskName, taskDeveloperDetails, taskStatus, search));
                    
                    //displays task and status of all tasks assigned to a developer the user searches for
                    System.out.println("\nEnter a developer's name to see all tasks assigned to them: ");
                    search = x.nextLine();
                    System.out.println(searchDeveloper(AmountOfTasks, taskDeveloperDetails, taskName, taskStatus, search));
                    
                    //deletes task and all corresponding details in parallel arrays by taking user input
                    System.out.println("\nEnter a task name to delete: ");        
                    search = x.nextLine();               
                    
                    String output = deleteTask(taskName, taskDescription, taskDeveloperDetails, taskStatus, taskID, taskDuration, AmountOfTasks, found, search);
                    if (output.contains("successfully")){
                        found = true;
                    }
                    System.out.println(output);                    
                    break;//break to exit out of current loop's pass
                case 2:
                    System.out.println(displayReport(taskName, taskDescription, taskDeveloperDetails, taskStatus, taskID, taskDuration, AmountOfTasks, found));
                    break;
                case 3:
                    System.out.println("Your quiting the application");                    
                    break;
                default:
                    System.out.println("Invalid menu option");
            }
        }        
        x.close();
    }
    public static String longestTask(int amountTasks, int[] taskDuration, String[] taskDeveloperDetails){
        int longestTask = 0;
        int index = 0;
        for (int i = 0; i < amountTasks;i++){
            if (taskDuration[i] > longestTask){
                longestTask = taskDuration[i];
                index = i;
            }
        }
        String result = taskDeveloperDetails[index] + ", " + taskDuration[index];
        
        return result;
    }
    
    public static String searchTaskName(int amountTasks, String[] taskName, String[] taskDeveloperDetails, String[] taskStatus, String search){  
        
        for (int i = 0; i < amountTasks; i++){
            if (search.equals(taskName[i])){
                return (taskDeveloperDetails[i] + ", " + taskName[i]);
            }
        }
        return "None";
    }
    
    public static String searchDeveloper(int amountTasks, String[] taskDeveloperDetails, String[] taskName, String[] taskStatus, String search){
        
        for (int i = 0; i < amountTasks; i++){
            if (search.equals(taskDeveloperDetails[i])){
                return(taskName[i]);
            }
        }
        return "None";
    }
    
    public static String deleteTask(String[] taskName, String[] taskDescription, String[] taskDeveloperDetails, String[] taskStatus, String[] taskID, int[] taskDuration, int amountTasks, boolean found, String search){
        
            for (int i = 0; i < amountTasks; i++){
                if (search.equals(taskName[i]) && i == taskName.length - 1){
                    found = true;
                    taskName[i] = "";
                    taskDescription[i] = "";
                    taskStatus[i] = "";
                    taskID[i] = "";
                    taskDuration[i] = 0;
                }else if(search.equals(taskName[i])){
                    found = true;
                    taskName[i] = taskName[i + 1];
                    taskDescription[i] = taskDescription[i + 1];
                    taskDeveloperDetails[i] = taskDeveloperDetails[i + 1];
                    taskStatus[i] = taskStatus[i + 1];
                    taskDuration[i] = taskDuration[i + 1];
                    taskID[i] = taskID[i + 1];
                }else if (found == true && i == amountTasks - 1){
                    taskName[i] = "";
                    taskDescription[i] = "";
                    taskDeveloperDetails[i] = "";
                    taskStatus[i] = "";
                    taskID[i] = "";
                    taskDuration[i] = 0;
                }else if(found == true){
                    taskName[i] = taskName[i + 1];
                    taskDescription[i] = taskDescription[i + 1];
                    taskDeveloperDetails[i] = taskDeveloperDetails[i + 1];
                    taskStatus[i] = taskStatus[i + 1];
                    taskID[i] = taskID[i + 1];
                    taskDuration[i] = taskDuration[i + 1];
                }
            }
            //outputs that task was successfully deleted
            if (found == true){
                return "\nEntry '" + search + "' successfully deleted\n";
            }else{
                return "\nEntry '" + search + "' was not found and could not be deleted\n";
            }
    }
    
    public static String displayReport(String[] taskName, String[] taskDescription, String[] taskDeveloperDetails, String[] taskID, String[] taskStatus, int[] taskDuration, int amountTasks, boolean found){
        String report = "";
        if (taskName == null){
            report = ("Please add tasks before choosing this option\n");
        }else if (found == true){
            for (int i = 0; i < amountTasks - 1; i++){
                report = report + ("Task Name: " + taskName[i] + " | Task Description: " + taskDescription[i] + " | Developer: " + taskDeveloperDetails[i] 
                + " | Task ID: " + taskID[i] + " | Task Duration: " + taskDuration[i] + " | Task Status: " + taskStatus[i] + "\n");
            }
        }else if (found == false){
            report = "";
            for (int i = 0; i < amountTasks; i++){
                report = report + ("Task Name: " + taskName[i] + " | Task Description: " + taskDescription[i] + " | Developer: " + taskDeveloperDetails[i] 
                + " | Task ID: " + taskID[i] + " | Task Duration: " + taskDuration[i] + " | Task Status: " + taskStatus[i] + "\n");
            }
        }
        return report;
           
        
}
}
        
        
    


