/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.part3demo;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author Wandile
 */
public class Part3Demo {

    public static void main(String[] args) {
       
          Scanner input = new Scanner(System.in);
        Map<String , String>dataMap = new HashMap<>();
        int choice;
        do{ 
           System.out.println("Please Choose from the following Options!");
           System.out.println("1.Display Report");
           System.out.println("2.Display Longest Task");
           System.out.println("3.Display Shortest Task");
           System.out.println("4.Search for Task");
           System.out.println("5.Delete specific Task");
           System.out.println("6.Display Report for captured Tasks");
           System.out.println("7.Exit System!");
           choice=input.nextInt();
           switch(choice){
               case 1 -> {
                   
        System.out.println("Display Report");
        String Developer[] = {"Developer:Mike Smith","Developer:Edward Harrison","Developer:Samantha Paulson","Developer:Glenda Oberholzer"};
        String TaskName[] = {"Task:Create Login","Task:Create add features","Task:Create Report","Task:Add Arrays"};
        String TaskID[] = {"TaskID:1","TaskID:2","TaskID:3","TaskID:4"};
        String TaskDuration[] = {"5hours","8hours","2hours","11hours"};
        String TaskStatus[] = {"TaskStatus:Done","TaskStatus:Done","TaskStatus:Done","TaskStatus:Done"};
        
        System.out.println(Developer[0]);
        System.out.println(TaskName[0]);
        System.out.println(TaskID[0]);
        System.out.println(TaskDuration[0]);
        System.out.println(TaskStatus[0]);
        System.out.println("=====================");
        
        System.out.println(Developer[1]);
        System.out.println(TaskName[1]);
        System.out.println(TaskID[1]);
        System.out.println(TaskDuration[1]);
        System.out.println(TaskStatus[1]);
          System.out.println("=====================");
        
        System.out.println(Developer[2]);
        System.out.println(TaskName[2]);
        System.out.println(TaskID[2]);
        System.out.println(TaskDuration[2]);
        System.out.println(TaskStatus[2]);
          System.out.println("=====================");
        
        System.out.println(Developer[3]);
        System.out.println(TaskName[3]);
        System.out.println(TaskID[3]);
        System.out.println(TaskDuration[3]);
        System.out.println(TaskStatus[3]);
        }
        case 2 -> { 
        String Developer[] = {"Developer:Mike Smith","Developer:Edward Harrison","Developer:Samantha Paulson","Developer:Glenda Oberholzer"};
        String TaskName[] = {"Task:Create Login","Task:Create add features","Task:Create Report","Task:Add Arrays"};
        String TaskID[] = {"TaskID:1","TaskID:2","TaskID:3","TaskID:4"};
        String TaskDuration[] = {"5hours","8hours","2hours","11hours"};
        String TaskStatus[] = {"TaskStatus:Done","TaskStatus:Done","TaskStatus:Done","TaskStatus:Done"};
        
        System.out.println(Developer[2]);
        System.out.println(TaskName[2]);
        System.out.println(TaskID[2]);
        System.out.println(TaskDuration[2]);
        System.out.println(TaskStatus[2]);
        System.out.println("=====================");
        }
        
        case 3 -> { 
        String Developer[] = {"Developer:Mike Smith","Developer:Edward Harrison","Developer:Samantha Paulson","Developer:Glenda Oberholzer"};
        String TaskName[] = {"Task:Create Login","Task:Create add features","Task:Create Report","Task:Add Arrays"};
        String TaskID[] = {"TaskID:1","TaskID:2","TaskID:3","TaskID:4"};
        String TaskDuration[] = {"5hours","8hours","2hours","11hours"};
        String TaskStatus[] = {"TaskStatus:Done","TaskStatus:Done","TaskStatus:Done","TaskStatus:Done"};
        
        System.out.println(Developer[1]);
        System.out.println(TaskName[1]);
        System.out.println(TaskID[1]);
        System.out.println(TaskDuration[1]);
        System.out.println(TaskStatus[1]);
        System.out.println("=====================");
        }
        
        case 4 -> {
            
          do{ 
           System.out.println("Please Select an option!");
           System.out.println("1.Task 1");
           System.out.println("2.Task 2");
           System.out.println("3.Task 3");
           System.out.println("4.Task4");
         System.out.println("5.Return to main program");
           choice=input.nextInt();
           switch(choice){
               case 1 -> {
        String Developer[] = {"Developer:Mike Smith","Developer:Edward Harrison","Developer:Samantha Paulson","Developer:Glenda Oberholzer"};
        String TaskName[] = {"Task:Create Login","Task:Create add features","Task:Create Report","Task:Add Arrays"};
        String TaskID[] = {"TaskID:1","TaskID:2","TaskID:3","TaskID:4"};
        String TaskDuration[] = {"5hours","8hours","2hours","11hours"};
        String TaskStatus[] = {"TaskStatus:Done","TaskStatus:Done","TaskStatus:Done","TaskStatus:Done"};
        
        System.out.println(Developer[0]);
        System.out.println(TaskName[0]);
        System.out.println(TaskID[0]);
        System.out.println(TaskDuration[0]);
        System.out.println(TaskStatus[0]);
        System.out.println("=====================");
        
               }
               case 2 -> {
        String Developer[] = {"Developer:Mike Smith","Developer:Edward Harrison","Developer:Samantha Paulson","Developer:Glenda Oberholzer"};
        String TaskName[] = {"Task:Create Login","Task:Create add features","Task:Create Report","Task:Add Arrays"};
        String TaskID[] = {"TaskID:1","TaskID:2","TaskID:3","TaskID:4"};
        String TaskDuration[] = {"5hours","8hours","2hours","11hours"};
        String TaskStatus[] = {"TaskStatus:Done","TaskStatus:Done","TaskStatus:Done","TaskStatus:Done"};
        
        System.out.println(Developer[1]);
        System.out.println(TaskName[1]);
        System.out.println(TaskID[1]);
        System.out.println(TaskDuration[1]);
        System.out.println(TaskStatus[1]);
        System.out.println("=====================");
               }
               case 3 ->{
        String Developer[] = {"Developer:Mike Smith","Developer:Edward Harrison","Developer:Samantha Paulson","Developer:Glenda Oberholzer"};
        String TaskName[] = {"Task:Create Login","Task:Create add features","Task:Create Report","Task:Add Arrays"};
        String TaskID[] = {"TaskID:1","TaskID:2","TaskID:3","TaskID:4"};
        String TaskDuration[] = {"5hours","8hours","2hours","11hours"};
        String TaskStatus[] = {"TaskStatus:Done","TaskStatus:Done","TaskStatus:Done","TaskStatus:Done"};
        
        System.out.println(Developer[2]);
        System.out.println(TaskName[2]);
        System.out.println(TaskID[2]);
        System.out.println(TaskDuration[2]);
        System.out.println(TaskStatus[2]);
        System.out.println("=====================");
               }
               case 4 ->{
        String Developer[] = {"Developer:Mike Smith","Developer:Edward Harrison","Developer:Samantha Paulson","Developer:Glenda Oberholzer"};
        String TaskName[] = {"Task:Create Login","Task:Create add features","Task:Create Report","Task:Add Arrays"};
        String TaskID[] = {"TaskID:1","TaskID:2","TaskID:3","TaskID:4"};
        String TaskDuration[] = {"5hours","8hours","2hours","11hours"};
        String TaskStatus[] = {"TaskStatus:Done","TaskStatus:Done","TaskStatus:Done","TaskStatus:Done"};
        System.out.println(Developer[3]);
        System.out.println(TaskName[3]);
        System.out.println(TaskID[3]);
        System.out.println(TaskDuration[3]);
        System.out.println(TaskStatus[3]);  
               }       
               
           }
        }while(choice!=5);
                
       
        }
        
        case 5 ->{
         System.out.println("Enter task you wish to delete!");
         String TaskName =input.nextLine();
         
         System.out.println(TaskName);
         
         }
         
        
            
       
        
        case 6 ->{
        String Developer[] = {"Developer:Mike Smith","Developer:Edward Harrison","Developer:Samantha Paulson","Developer:Glenda Oberholzer"};
        String TaskName[] = {"Task:Create Login","Task:Create add features","Task:Create Report","Task:Add Arrays"};
        String TaskID[] = {"TaskID:1","TaskID:2","TaskID:3","TaskID:4"};
        String TaskDuration[] = {"5hours","8hours","2hours","11hours"};
        String TaskStatus[] = {"TaskStatus:Done","TaskStatus:Done","TaskStatus:Done","TaskStatus:Done"};
        }
        case 7 ->{
        String Developer[] = {"Developer:Mike Smith","Developer:Edward Harrison","Developer:Samantha Paulson","Developer:Glenda Oberholzer"};
        String TaskName[] = {"Task:Create Login","Task:Create add features","Task:Create Report","Task:Add Arrays"};
        String TaskID[] = {"TaskID:1","TaskID:2","TaskID:3","TaskID:4"};
        String TaskDuration[] = {"5hours","8hours","2hours","11hours"};
        String TaskStatus[] = {"TaskStatus:Done","TaskStatus:Done","TaskStatus:Done","TaskStatus:Done"};
        }
            
               
         }
        }while(choice!=7);
         input.close();
    }
}
